/****************************************************************************************

   Copyright (C) 2015 Autodesk, Inc.
   All rights reserved.

   Use of this software is subject to the terms of the Autodesk license agreement
   provided at the time of installation or download, or which otherwise accompanies
   this software in either electronic or hard copy form.
 
****************************************************************************************/

#include <fbxsdk.h>
#include "DisplayCommon.h"

#if defined (FBXSDK_ENV_MAC)
// disable the �format not a string literal and no format arguments?warning since
// the PrintToFile calls made here are all valid calls and there is no secuity risk
#pragma GCC diagnostic ignored "-Wformat-security"
#endif

void DisplayHierarchy(int *pnFrame, FbxNode *pfbxNode, int nTabIndents);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
FbxAMatrix GetGeometricOffsetTransform(FbxNode *pfbxNode)
{
	const FbxVector4 T = pfbxNode->GetGeometricTranslation(FbxNode::eSourcePivot);
	const FbxVector4 R = pfbxNode->GetGeometricRotation(FbxNode::eSourcePivot);
	const FbxVector4 S = pfbxNode->GetGeometricScaling(FbxNode::eSourcePivot);

	return(FbxAMatrix(T, R, S));
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
void DisplayPolygonVertexColors(FbxMesh *pfbxMesh, int nPolygons, int nTabIndents)
{
	int nColorsPerVertex = pfbxMesh->GetElementVertexColorCount();
	if (nColorsPerVertex > 0)
	{
		int nColors = 0;
		for (int i = 0; i < nPolygons; i++) nColors += pfbxMesh->GetPolygonSize(i) * nColorsPerVertex;

		DisplayInt("<Colors>: ", nColors, nColorsPerVertex, " ", nTabIndents);
		for (int k = 0; k < nColorsPerVertex; k++)
		{
			DisplayInt("<Color>: ", k, " ", nTabIndents + 1);
			FbxGeometryElementVertexColor *pfbxElementVertexColor = pfbxMesh->GetElementVertexColor(k);
			for (int i = 0, nVertexID = 0; i < nPolygons; i++)
			{
				int nPolygonSize = pfbxMesh->GetPolygonSize(i); //Triangle: 3, Triangulate()
				for (int j = 0; j < nPolygonSize; j++, nVertexID++)
				{
					int nControlPointIndex = pfbxMesh->GetPolygonVertex(i, j);
					switch (pfbxElementVertexColor->GetMappingMode())
					{
						case FbxGeometryElement::eByControlPoint:
							switch (pfbxElementVertexColor->GetReferenceMode())
							{
								case FbxGeometryElement::eDirect:
									DisplayColor(pfbxElementVertexColor->GetDirectArray().GetAt(nControlPointIndex));
									break;
								case FbxGeometryElement::eIndexToDirect:
									DisplayColor(pfbxElementVertexColor->GetDirectArray().GetAt(pfbxElementVertexColor->GetIndexArray().GetAt(nControlPointIndex)));
									break;
								default:
									break;
							}
							break;
						case FbxGeometryElement::eByPolygonVertex:
							switch (pfbxElementVertexColor->GetReferenceMode())
							{
								case FbxGeometryElement::eDirect:
									DisplayColor(pfbxElementVertexColor->GetDirectArray().GetAt(nVertexID));
									break;
								case FbxGeometryElement::eIndexToDirect:
									DisplayColor(pfbxElementVertexColor->GetDirectArray().GetAt(pfbxElementVertexColor->GetIndexArray().GetAt(nVertexID)));
									break;
								default:
									break;
							}
							break;
						case FbxGeometryElement::eByPolygon:
						case FbxGeometryElement::eAllSame:
						case FbxGeometryElement::eNone:
							break;
						default:
							break;
					}
				}
			}
		}
		WriteStringToFile("\n");
	}
}

void DisplayPolygonVertexUVs(FbxMesh *pfbxMesh, int nPolygons, int nTabIndents)
{
	int nUVsPerVertex = pfbxMesh->GetElementUVCount(); //UVs Per Polygon's Vertex
	if (nUVsPerVertex > 0)
	{
		int nUVs = 0;
		for (int i = 0; i < nPolygons; i++) nUVs += pfbxMesh->GetPolygonSize(i) * nUVsPerVertex;

		DisplayInt("<UVs>: ", nUVs, nUVsPerVertex, "\n", nTabIndents);
		for (int k = 0; k < nUVsPerVertex; k++)
		{
			DisplayInt("<UV>: ", k, " ", nTabIndents + 1);
			for (int i = 0; i < nPolygons; i++)
			{
				int nPolygonSize = pfbxMesh->GetPolygonSize(i); //Triangle: 3, Triangulate()
				for (int j = 0; j < nPolygonSize; j++)
				{
					int nControlPointIndex = pfbxMesh->GetPolygonVertex(i, j);
					FbxGeometryElementUV *pfbxElementUV = pfbxMesh->GetElementUV(k);
					switch (pfbxElementUV->GetMappingMode())
					{
						case FbxGeometryElement::eByControlPoint:
							switch (pfbxElementUV->GetReferenceMode())
							{
								case FbxGeometryElement::eDirect:
									Display2DVector(pfbxElementUV->GetDirectArray().GetAt(nControlPointIndex));
									break;
								case FbxGeometryElement::eIndexToDirect:
									Display2DVector(pfbxElementUV->GetDirectArray().GetAt(pfbxElementUV->GetIndexArray().GetAt(nControlPointIndex)));
									break;
								default:
									break;
							}
							break;
						case FbxGeometryElement::eByPolygonVertex:
							{
								int nTextureUVIndex = pfbxMesh->GetTextureUVIndex(i, j);
								switch (pfbxElementUV->GetReferenceMode())
								{
									case FbxGeometryElement::eDirect:
									case FbxGeometryElement::eIndexToDirect:
										Display2DVector(pfbxElementUV->GetDirectArray().GetAt(nTextureUVIndex));
										break;
									default:
										break;
								}
							}
							break;
						case FbxGeometryElement::eByPolygon:
						case FbxGeometryElement::eAllSame:
						case FbxGeometryElement::eNone:
							break;
						default:
							break;
					}
				}
			}
		}
		WriteStringToFile("\n");
	}
}

void DisplayPolygonVertexNormals(FbxMesh *pfbxMesh, int nPolygons, int nTabIndents)
{
	int nNormalsPerVertex = pfbxMesh->GetElementNormalCount();
	if (nNormalsPerVertex > 0)
	{
		int nNormals = 0;
		for (int i = 0; i < nPolygons; i++) nNormals += pfbxMesh->GetPolygonSize(i) * nNormalsPerVertex;

		DisplayInt("<Normals>: ", nNormals, nNormalsPerVertex, "\n", nTabIndents);
		for (int k = 0; k < nNormalsPerVertex; k++)
		{
			FbxGeometryElementNormal *pfbxElementNormal = pfbxMesh->GetElementNormal(k);
			DisplayInt("<Normal>: ", k, " ", nTabIndents + 1);
			for (int i = 0, nVertexID = 0; i < nPolygons; i++)
			{
				int nPolygonSize = pfbxMesh->GetPolygonSize(i);
				for (int j = 0; j < nPolygonSize; j++, nVertexID++)
				{
					int nControlPointIndex = pfbxMesh->GetPolygonVertex(i, j);
					if (pfbxElementNormal->GetMappingMode() == FbxGeometryElement::eByPolygonVertex)
					{
						switch (pfbxElementNormal->GetReferenceMode())
						{
							case FbxGeometryElement::eDirect:
								Display3DVector(pfbxElementNormal->GetDirectArray().GetAt(nVertexID));
								break;
							case FbxGeometryElement::eIndexToDirect:
								Display3DVector(pfbxElementNormal->GetDirectArray().GetAt(pfbxElementNormal->GetIndexArray().GetAt(nVertexID)));
								break;
							default:
								break;
						}
					}
				}
			}
		}
		WriteStringToFile("\n");
	}
}

void DisplayPolygonVertexTangents(FbxMesh *pfbxMesh, int nPolygons, int nTabIndents)
{
	int nTangentsPerVertex = pfbxMesh->GetElementTangentCount();
	if (nTangentsPerVertex > 0)
	{
		int nTangents = 0;
		for (int i = 0; i < nPolygons; i++) nTangents += pfbxMesh->GetPolygonSize(i) * nTangentsPerVertex;

		DisplayInt("<Tangents>: ", nTangents, nTangentsPerVertex, "\n", nTabIndents);
		for (int k = 0; k < nTangentsPerVertex; k++)
		{
			DisplayInt("<Tangent>: ", k, " ", nTabIndents + 1);
			FbxGeometryElementTangent *pfbxElementTangent = pfbxMesh->GetElementTangent(k);
			for (int i = 0, nVertexID = 0; i < nPolygons; i++)
			{
				int nPolygonSize = pfbxMesh->GetPolygonSize(i);
				for (int j = 0; j < nPolygonSize; j++, nVertexID++)
				{
					int nControlPointIndex = pfbxMesh->GetPolygonVertex(i, j);
					if (pfbxElementTangent->GetMappingMode() == FbxGeometryElement::eByPolygonVertex)
					{
						switch (pfbxElementTangent->GetReferenceMode())
						{
							case FbxGeometryElement::eDirect:
								Display3DVector(pfbxElementTangent->GetDirectArray().GetAt(nVertexID));
								break;
							case FbxGeometryElement::eIndexToDirect:
								Display3DVector(pfbxElementTangent->GetDirectArray().GetAt(pfbxElementTangent->GetIndexArray().GetAt(nVertexID)));
								break;
							default:
								break;
						}
					}
				}
			}
		}
		WriteStringToFile("\n");
	}
}

void DisplayPolygonVertexBinormals(FbxMesh *pfbxMesh, int nPolygons, int nTabIndents)
{
	int nBinormalsPerVertex = pfbxMesh->GetElementBinormalCount();
	if (nBinormalsPerVertex > 0)
	{
		int nBinormals = 0;
		for (int i = 0; i < nPolygons; i++) nBinormals += pfbxMesh->GetPolygonSize(i) * nBinormalsPerVertex;

		DisplayInt("<Binormals>: ", nBinormals, nBinormalsPerVertex, "\n", nTabIndents);
		for (int k = 0; k < nBinormalsPerVertex; k++)
		{
			FbxGeometryElementBinormal *pfbxElementBinormal = pfbxMesh->GetElementBinormal(k);
			DisplayInt("<Binormal>: ", k, " ", nTabIndents + 1);
			for (int i = 0, nVertexID = 0; i < nPolygons; i++)
			{
				int nPolygonSize = pfbxMesh->GetPolygonSize(i);
				for (int j = 0; j < nPolygonSize; j++, nVertexID++)
				{
					if (pfbxElementBinormal->GetMappingMode() == FbxGeometryElement::eByPolygonVertex)
					{
						switch (pfbxElementBinormal->GetReferenceMode())
						{
							case FbxGeometryElement::eDirect:
								Display3DVector(pfbxElementBinormal->GetDirectArray().GetAt(nVertexID));
								break;
							case FbxGeometryElement::eIndexToDirect:
								Display3DVector(pfbxElementBinormal->GetDirectArray().GetAt(pfbxElementBinormal->GetIndexArray().GetAt(nVertexID)));
								break;
							default:
								break;
						}
					}
				}
			}
		}
		WriteStringToFile("\n");
	}
}

void DisplayPolygonVertexIndices(FbxMesh *pfbxMesh, int nPolygons, int nTabIndents)
{
	int nPolygonIndices = nPolygons * 3; //Triangle: 3, Triangulate(), nIndices = nPolygons * 3

	int *pnPolygonIndices = new int[nPolygonIndices];
	for (int i = 0, k = 0; i < nPolygons; i++)
	{
		for (int j = 0; j < 3; j++) pnPolygonIndices[k++] = pfbxMesh->GetPolygonVertex(i, j);
	}

	FbxNode *pfbxNode = pfbxMesh->GetNode();
    int nMaterials = pfbxNode->GetMaterialCount();
	DisplayInt("<SubIndices>: ", nPolygonIndices, nMaterials, "\n", nTabIndents);

	if (nMaterials > 1)
	{
		int nElementMaterials = pfbxMesh->GetElementMaterialCount();
		for (int i = 0; i < nElementMaterials; i++)
		{
			FbxGeometryElementMaterial *pfbxElementMaterial = pfbxMesh->GetElementMaterial(i);
			FbxGeometryElement::EReferenceMode nReferenceMode = pfbxElementMaterial->GetReferenceMode();
			switch (nReferenceMode)
			{
				case FbxGeometryElement::eDirect:
				{
					DisplayInt("<SubIndex>: ", 0, nPolygonIndices, "", nTabIndents + 1);
					for (int i = 0; i < nPolygonIndices; i++) DisplayInt(pnPolygonIndices[i]);
					WriteStringToFile("\n");
					break;
				}
				case FbxGeometryElement::eIndex:
				case FbxGeometryElement::eIndexToDirect:
				{
					int *pnSubIndices = new int[nMaterials];
					memset(pnSubIndices, 0, sizeof(int) * nMaterials);

					int nSubIndices = pfbxElementMaterial->GetIndexArray().GetCount();
					for (int j = 0; j < nSubIndices; j++) pnSubIndices[pfbxElementMaterial->GetIndexArray().GetAt(j)]++;

					int **ppnSubIndices = new int*[nMaterials];
					for (int k = 0; k < nMaterials; k++)
					{
						pnSubIndices[k] *= 3;
						ppnSubIndices[k] = new int[pnSubIndices[k]];
					}

					int *pnToAppends = new int[nMaterials];
					memset(pnToAppends, 0, sizeof(int) * nMaterials);
					for (int j = 0, k = 0; j < nSubIndices; j++)
					{
						int nMaterial = pfbxElementMaterial->GetIndexArray().GetAt(j);
						for (int i = 0; i < 3; i++) ppnSubIndices[nMaterial][pnToAppends[nMaterial]++] = pnPolygonIndices[k++];
					}

					for (int k = 0; k < nMaterials; k++)
					{
						DisplayInt("<SubIndex>: ", k, pnSubIndices[k], "", nTabIndents + 1);
						for (int j = 0; j < pnSubIndices[k]; j++) DisplayInt(ppnSubIndices[k][j]);
						WriteStringToFile("\n");
					}

					if (pnSubIndices) delete[] pnSubIndices;
					for (int k = 0; k < nMaterials; k++) if (ppnSubIndices[k]) delete[] ppnSubIndices[k];
					if (ppnSubIndices) delete[] ppnSubIndices;
					if (pnToAppends) delete[] pnToAppends;

					break;
				}
			}
		}
	}
	else
	{
		DisplayInt("<SubIndex>: ", 0, nPolygonIndices, "", nTabIndents + 1);
		for (int i = 0; i < nPolygonIndices; i++) DisplayInt(pnPolygonIndices[i]);
		WriteStringToFile("\n");
	}

	if (pnPolygonIndices) delete[] pnPolygonIndices;
}

void DisplayTextureInfo(FbxTexture *pfbxTexture, int nBlendMode)
{
	DisplayString(ReplaceBlank(pfbxTexture->GetName(), '_'));

	FbxFileTexture *pfbxFileTexture = FbxCast<FbxFileTexture>(pfbxTexture);
	if (pfbxFileTexture)
	{
		FbxString fbxPathName = pfbxFileTexture->GetRelativeFileName();
		FbxString fbxFileName = fbxPathName.Right(fbxPathName.GetLen() - fbxPathName.ReverseFind('\\') - 1);
		DisplayIntString(" ", 0, ReplaceBlank(fbxFileName.Buffer(), '_'), " "); //0:"File Texture"
	}
	else 
	{
		FbxProceduralTexture *pfbxProceduralTexture = FbxCast<FbxProceduralTexture>(pfbxTexture);
		if (pfbxProceduralTexture) DisplayInt(" ", 1, " "); //1:"Procedural Texture"
	}

    DisplayFloat(pfbxTexture->GetScaleU(), pfbxTexture->GetScaleV());
    DisplayFloat(pfbxTexture->GetTranslationU(), pfbxTexture->GetTranslationV());
    DisplayBool(pfbxTexture->GetSwapUV());
    DisplayFloat(pfbxTexture->GetRotationU(), pfbxTexture->GetRotationV(), pfbxTexture->GetRotationW());

    DisplayInt(pfbxTexture->GetAlphaSource()); //Alpha Source: 0:"None", 1:"Intensity", 2:"Black"
    DisplayInt(pfbxTexture->GetCroppingLeft(), pfbxTexture->GetCroppingTop(), pfbxTexture->GetCroppingRight(), pfbxTexture->GetCroppingBottom());

    DisplayInt(pfbxTexture->GetMappingType()); //Mapping Type: 0:"Null", 1:"Planar", 2:"Spherical", 3:"Cylindrical", 4:"Box", 5:"Face", 6:"UV", 7:"Environment"
    if (pfbxTexture->GetMappingType() == FbxTexture::ePlanar) DisplayInt(pfbxTexture->GetPlanarMappingNormal()); //PlanarMappingNormal: 0:"X", 1:"Y", 2:"Z"
   
    DisplayInt(nBlendMode); //Blend Mode: -1:"None", 0:"Translucent", 1:"Additive", 2:"Modulate", 3:"Modulate2", 4:"Over", 5:"Normal", 6:"Dissolve", 7:"Darken", 8:"ColorBurn", 9:"LinearBurn", 10:"DarkerColor", "Lighten", "Screen", "ColorDodge", "LinearDodge", "LighterColor", "SoftLight", "HardLight", "VividLight", "LinearLight", "PinLight", "HardMix", "Difference", "Exclusion", "Substract", "Divide", "Hue", "Saturation", "Color", "Luminosity", "Overlay"

	DisplayFloat(pfbxTexture->GetDefaultAlpha()); //Default Alpha

	DisplayInt((pfbxFileTexture) ? pfbxFileTexture->GetMaterialUse() : -1); //Material Use: 0:"Model Material", 1:"Default Material"

    DisplayInt(pfbxTexture->GetTextureUse()); //Texture Use: 0:"Standard", 1:"Shadow Map", 2:"Light Map", 3:"Spherical Reflexion Map", 4:"Sphere Reflexion Map", 5:"Bump Normal Map"

    DisplayString("\n");                
}

void FindAndDisplayTextureInfoByProperty(FbxSurfaceMaterial *pfbxMaterial, FbxProperty *pfbxProperty, int nTabIndents)
{
    if (pfbxProperty->IsValid())
    {
		int nLayeredTextures = pfbxProperty->GetSrcObjectCount<FbxLayeredTexture>();
		if (nLayeredTextures > 0)
		{
			DisplayInt("<LayeredTextures>: ", nLayeredTextures, "\n", nTabIndents);
			for (int i = 0; i < nLayeredTextures; i++)
			{
				FbxLayeredTexture *pfbxLayeredTexture = pfbxProperty->GetSrcObject<FbxLayeredTexture>(i);
				int nTextures = pfbxLayeredTexture->GetSrcObjectCount<FbxTexture>();
				DisplayInt("<LayeredTexture>: ", i, nTextures, "\n", nTabIndents + 1);
				for (int j = 0; j < nTextures; j++)
				{
					FbxTexture *pfbxTexture = pfbxLayeredTexture->GetSrcObject<FbxTexture>(j);
					if (pfbxTexture)
					{
						DisplayInt("<Texture>: ", j, " ", nTabIndents + 2);
						FbxLayeredTexture::EBlendMode nBlendMode;
						pfbxLayeredTexture->GetTextureBlendMode(j, nBlendMode);
						DisplayTextureInfo(pfbxTexture, (int)nBlendMode);
					}
				}
			}
		}
		else
		{
			int nTextures = pfbxProperty->GetSrcObjectCount<FbxTexture>();
			DisplayInt("<Textures>: ", nTextures, "\n", nTabIndents);
			if (nTextures > 0)
			{
				for (int j = 0; j < nTextures; j++)
				{
					FbxTexture *pfbxTexture = pfbxProperty->GetSrcObject<FbxTexture>(j);
					if (pfbxTexture)
					{
						DisplayInt("<Texture>: ", j, " ", nTabIndents + 1);
						DisplayTextureInfo(pfbxTexture, -1);
					}
				}
			}
		}
    }
}

void DisplayHardwareShaderImplementation(FbxSurfaceMaterial *pfbxMaterial, const FbxImplementation *pfbxImplementation, FbxString fbxstrImplemenationType, int nTabIndents)
{
    if (pfbxImplementation)
    {
        const FbxBindingTable *pfbxRootTable = pfbxImplementation->GetRootTable();
        FbxString fbxstrFileName = "\"" + pfbxRootTable->DescAbsoluteURL.Get() + "\"";
        FbxString fbxstrTechniqueName = "\"" + pfbxRootTable->DescTAG.Get() + "\""; 

		DisplayString("<HardwareShader>: ", ReplaceBlank(fbxstrImplemenationType.Buffer(), '_'), fbxstrFileName.Buffer(), fbxstrTechniqueName.Buffer(), "\n", nTabIndents);

        const FbxBindingTable *pfbxTable = pfbxImplementation->GetRootTable();
        int nEntries = (int)pfbxTable->GetEntryCount();

		DisplayInt("<Entries>: ", nEntries, "\n", nTabIndents + 1);
        for (int i = 0; i < nEntries; i++)
        {
            const FbxBindingTableEntry& fbxEntry = pfbxTable->GetEntry(i);
            const char *pstrEntrySrcType = fbxEntry.GetEntryType(true); 

			DisplayIntString("<Entry>: ", i, fbxEntry.GetSource(), "\n", nTabIndents + 2);

            FbxProperty fbxProperty;
            if (!strcmp(FbxPropertyEntryView::sEntryType, pstrEntrySrcType))
            {   
                fbxProperty = pfbxMaterial->FindPropertyHierarchical(fbxEntry.GetSource()); 
                if (!fbxProperty.IsValid())
                {
                    fbxProperty = pfbxMaterial->RootProperty.FindHierarchical(fbxEntry.GetSource());
                }
            }
            else if (!strcmp(FbxConstantEntryView::sEntryType, pstrEntrySrcType))
            {
                fbxProperty = pfbxImplementation->GetConstants().FindHierarchical(fbxEntry.GetSource());
            }

            if (fbxProperty.IsValid())
            {
				int nTextures = fbxProperty.GetSrcObjectCount<FbxTexture>();
                if (nTextures > 0)
                {
					DisplayInt("<Textures>: ", nTextures, "\n", nTabIndents + 3);

					int nFileTextures = fbxProperty.GetSrcObjectCount<FbxFileTexture>();
					DisplayInt("<FileTextures>: ", nFileTextures, " ", nTabIndents + 4);
                    for (int j = 0; j < nFileTextures; j++)
                    {
                        FbxFileTexture *pfbxFileTexture = fbxProperty.GetSrcObject<FbxFileTexture>(j);
                        DisplayString("", pfbxFileTexture->GetFileName(), " ");
                    }
					DisplayString("\n");

					int nLayeredTextures = fbxProperty.GetSrcObjectCount<FbxLayeredTexture>();
					DisplayInt("<LayeredTextures>: ", nLayeredTextures, " ", nTabIndents + 4);
                    for (int j = 0; j < nLayeredTextures; j++)
                    {
                        FbxLayeredTexture *pfbxLayeredTexture = fbxProperty.GetSrcObject<FbxLayeredTexture>(j);
                        DisplayString("", pfbxLayeredTexture->GetName(), " ");
                    }
					DisplayString("\n");

					int nProceduralTextures = fbxProperty.GetSrcObjectCount<FbxProceduralTexture>();
					DisplayInt("<ProceduralTextures>: ", nProceduralTextures, " ", nTabIndents + 4);
                    for(int j = 0; j < nProceduralTextures; ++j)
                    {
                        FbxProceduralTexture *pfbxProceduralTexture = fbxProperty.GetSrcObject<FbxProceduralTexture>(j);
                        DisplayString("", pfbxProceduralTexture->GetName(), " ");
                    }
					DisplayString("</Textures>", "", "\n", nTabIndents + 3);
                }
                else
                {
					FbxDataType lFbxType = fbxProperty.GetPropertyDataType();
                    if (FbxBoolDT == lFbxType)
                    {
                        DisplayBool("<Bool>: ", fbxProperty.Get<FbxBool>(), "\n", nTabIndents + 3);
                    }
                    else if ((FbxIntDT == lFbxType) || (FbxEnumDT == lFbxType))
                    {
                        DisplayInt("<Int>: ", fbxProperty.Get<FbxInt>(), "\n", nTabIndents + 3);
                    }
                    else if (FbxFloatDT == lFbxType)
                    {
                        DisplayFloat("<Float>: ", fbxProperty.Get<FbxFloat>(), "\n", nTabIndents + 3);
                    }
                    else if (FbxDoubleDT == lFbxType)
                    {
                        DisplayDouble("<Double>: ", fbxProperty.Get<FbxDouble>(), "\n", nTabIndents + 3);
                    }
                    else if ((FbxStringDT == lFbxType) || (FbxUrlDT == lFbxType) || (FbxXRefUrlDT == lFbxType))
                    {
                        DisplayString("<String>: ", fbxProperty.Get<FbxString>().Buffer(), "\n", nTabIndents + 3);
                    }
                    else if (FbxDouble2DT == lFbxType)
                    {
                        Display2DVector("<Vector2D>: ", fbxProperty.Get<FbxDouble2>(), "\n", nTabIndents + 3);
                    }
                    else if ((FbxDouble3DT == lFbxType) || (FbxColor3DT == lFbxType))
                    {
                        Display3DVector("<Vector3D>: ", fbxProperty.Get<FbxDouble3>(), "\n", nTabIndents + 3);
                    }
                    else if ((FbxDouble4DT == lFbxType) || (FbxColor4DT == lFbxType))
                    {
                        Display4DVector("<Vector4D>: ", fbxProperty.Get<FbxDouble4>(), "\n", nTabIndents + 3);
                    }
                    else if (FbxDouble4x4DT == lFbxType)
                    {
						DisplayMatrix("<Matrix>: ", fbxProperty.Get<FbxDouble4x4>(), "\n", nTabIndents + 3);
                    }
					else
					{
						DisplayString("<Unknown>", "", "\n", nTabIndents + 3);
					}
                }
            }   
        }
		DisplayString("</Entries>", " ", "\n", nTabIndents + 1);
    }
}

void DisplayMaterials(FbxMesh *pfbxMesh, int nTabIndents)
{
	FbxNode *pfbxNode = pfbxMesh->GetNode();
	if (pfbxNode)
	{
		int nMaterials = pfbxNode->GetMaterialCount();
		DisplayInt("<Materials>: ", nMaterials, "\n", nTabIndents);

		for (int i = 0; i < nMaterials; i++)
		{
            FbxSurfaceMaterial *pfbxMaterial = pfbxNode->GetMaterial(i);
			if (pfbxMaterial)
			{
				DisplayIntString("<Material>: ", i, ReplaceBlank(pfbxMaterial->GetName(), '_'), "\n", nTabIndents + 1);

				int nProperties = FbxLayerElement::sTypeTextureCount;		
				DisplayInt("<TextureProperties>: ", nProperties, "\n", nTabIndents + 2);
				for (int j = 0; j < nProperties; j++)
				{
					FbxProperty fbxProperty = pfbxMaterial->FindProperty(FbxLayerElement::sTextureChannelNames[j]);
					DisplayIntString("<Property>: ", j, FbxLayerElement::sTextureChannelNames[j], ReplaceBlank(fbxProperty.GetName(), '_'), "\n", nTabIndents + 3);
//0:DiffuseColor(FbxSurfaceMaterial::sDiffuse), 1:DiffuseFactor, 2:EmissiveColor, 3:EmissiveFactor, 4:AmbientColor, 5:AmbientFactor, 6:SpecularColor, 7:SpecularFactor, 8:ShininessExponent
//9:NormalMap, 10:Bump, 11:TransparentColor, 12:TransparencyFactor, 13:ReflectionColor, 14:ReflectionFactor, 15:DisplacementColor, 16:VectorDisplacementColor
					FindAndDisplayTextureInfoByProperty(pfbxMaterial, &fbxProperty, nTabIndents + 4);
				}
				DisplayString("</TextureProperties>", "", "\n", nTabIndents + 2);

				DisplayString("<ShadingModel>: ", ReplaceBlank((char *)pfbxMaterial->ShadingModel.Get().Buffer(), '_'), "\n", nTabIndents + 2);

				FbxString fbxstrImplemenationType = "HLSL";
				const FbxImplementation *pfbxImplementation = GetImplementation(pfbxMaterial, FBXSDK_IMPLEMENTATION_HLSL);
				if (!pfbxImplementation)
				{
					pfbxImplementation = GetImplementation(pfbxMaterial, FBXSDK_IMPLEMENTATION_CGFX);
					fbxstrImplemenationType = "CGFX";
				}
				if (pfbxImplementation)
				{
					DisplayHardwareShaderImplementation(pfbxMaterial, pfbxImplementation, fbxstrImplemenationType, nTabIndents + 3);
				}
				else if (pfbxMaterial->GetClassId().Is(FbxSurfacePhong::ClassId))
				{
					DisplayString("<Phong>: ", "", "", nTabIndents + 3);

					FbxSurfacePhong *pfbxSurfacePhong = (FbxSurfacePhong *)pfbxMaterial;
					DisplayColor(pfbxSurfacePhong->Ambient);
					DisplayColor(pfbxSurfacePhong->Diffuse);
					DisplayColor(pfbxSurfacePhong->Specular);
					DisplayColor(pfbxSurfacePhong->Emissive);
					DisplayFloat((float)pfbxSurfacePhong->TransparencyFactor);
					DisplayFloat((float)pfbxSurfacePhong->Shininess);
					DisplayFloat((float)pfbxSurfacePhong->ReflectionFactor);
					DisplayString("\n");
				}
				else if (pfbxMaterial->GetClassId().Is(FbxSurfaceLambert::ClassId))
				{
					DisplayString("<Lambert>: ", "", "", nTabIndents + 3);

					FbxSurfaceLambert *pfbxSurfaceLambert = (FbxSurfaceLambert *)pfbxMaterial;
					DisplayColor(pfbxSurfaceLambert->Ambient);
					DisplayColor(pfbxSurfaceLambert->Diffuse);
					DisplayColor(pfbxSurfaceLambert->Emissive);
					DisplayFloat((float)pfbxSurfaceLambert->TransparencyFactor);
					DisplayString("\n");
				}
				else
				{
					DisplayString("<Unknown>", "", "", nTabIndents + 3);
				}
			}
		}
		DisplayString("</Materials>", "", "\n", nTabIndents);
	}
}

void DisplayControlPointUVs(FbxMesh *pfbxMesh, int nControlPoints, int nTabIndents)
{
	FbxVector2 *pControlPointUVs = new FbxVector2[nControlPoints];

	int nUVsPerVertex = pfbxMesh->GetElementUVCount(); //UVs Per Polygon's Vertex
	DisplayInt("<UVs>: ", nControlPoints, nUVsPerVertex, "\n", nTabIndents);

	if (nUVsPerVertex > 0)
	{
		int nPolygons = pfbxMesh->GetPolygonCount();

		for (int k = 0; k < nUVsPerVertex; k++)
		{
			DisplayInt("<UV>: ", k, " ", nTabIndents + 1);
			FbxGeometryElementUV *pfbxElementUV = pfbxMesh->GetElementUV(k);
			for (int i = 0; i < nPolygons; i++)
			{
				int nPolygonSize = pfbxMesh->GetPolygonSize(i); //Triangle: 3, Triangulate()
				for (int j = 0; j < nPolygonSize; j++)
				{
					int nControlPointIndex = pfbxMesh->GetPolygonVertex(i, j);
					switch (pfbxElementUV->GetMappingMode())
					{
						case FbxGeometryElement::eByControlPoint:
						{
							switch (pfbxElementUV->GetReferenceMode())
							{
								case FbxGeometryElement::eDirect:
									pControlPointUVs[nControlPointIndex] = pfbxElementUV->GetDirectArray().GetAt(nControlPointIndex);
									break;
								case FbxGeometryElement::eIndexToDirect:
									pControlPointUVs[nControlPointIndex] = pfbxElementUV->GetDirectArray().GetAt(pfbxElementUV->GetIndexArray().GetAt(nControlPointIndex));
									break;
								default:
									break;
							}
							break;
						}
						case FbxGeometryElement::eByPolygonVertex:
							{
								int nTextureUVIndex = pfbxMesh->GetTextureUVIndex(i, j);
								switch (pfbxElementUV->GetReferenceMode())
								{
									case FbxGeometryElement::eDirect:
									case FbxGeometryElement::eIndexToDirect:
										pControlPointUVs[nControlPointIndex] = pfbxElementUV->GetDirectArray().GetAt(nTextureUVIndex);
										break;
									default:
										break;
								}
								break;
							}
						case FbxGeometryElement::eByPolygon:
						case FbxGeometryElement::eAllSame:
						case FbxGeometryElement::eNone:
							break;
						default:
							break;
					}
				}
			}
			for (int i = 0; i < nControlPoints; i++) DisplayUV2DVector(pControlPointUVs[i]);
			WriteStringToFile("\n");
		}
	}
}

void DisplayControlPointColors(FbxMesh *pfbxMesh, int nControlPoints, int nTabIndents)
{
	FbxColor *pControlPointColors = new FbxColor[nControlPoints];

	int nColorsPerVertex = pfbxMesh->GetElementVertexColorCount();
	DisplayInt("<Colors>: ", nControlPoints, nColorsPerVertex, "\n", nTabIndents);

	if (nColorsPerVertex > 0)
	{
		int nPolygons = pfbxMesh->GetPolygonCount();

		for (int k = 0; k < nColorsPerVertex; k++)
		{
			DisplayInt("<Color>: ", k, " ", nTabIndents + 1);

			FbxGeometryElementVertexColor *pfbxElementColor = pfbxMesh->GetElementVertexColor(k);
			switch (pfbxElementColor->GetMappingMode())
			{
				case FbxGeometryElement::eByControlPoint:
					switch (pfbxElementColor->GetReferenceMode())
					{
						case FbxGeometryElement::eDirect:
							for (int i = 0; i < nControlPoints; i++) pControlPointColors[i] = pfbxElementColor->GetDirectArray().GetAt(i);
							break;
						case FbxGeometryElement::eIndexToDirect:
							for (int i = 0; i < nControlPoints; i++) pControlPointColors[i] = pfbxElementColor->GetDirectArray().GetAt(pfbxElementColor->GetIndexArray().GetAt(i));
							break;
					}
				case FbxGeometryElement::eByPolygonVertex:
					for (int i = 0, nVertexID = 0; i < nPolygons; i++)
					{
						int nPolygonSize = pfbxMesh->GetPolygonSize(i);
						for (int j = 0; j < nPolygonSize; j++, nVertexID++)
						{
							int nControlPointIndex = pfbxMesh->GetPolygonVertex(i, j);
							switch (pfbxElementColor->GetReferenceMode())
							{
								case FbxGeometryElement::eDirect:
									pControlPointColors[nControlPointIndex] = pfbxElementColor->GetDirectArray().GetAt(nVertexID);
									break;
								case FbxGeometryElement::eIndexToDirect:
									pControlPointColors[nControlPointIndex] = pfbxElementColor->GetDirectArray().GetAt(pfbxElementColor->GetIndexArray().GetAt(nVertexID));
									break;
								default:
									break;
							}
						}
					}
					break;
			}

			for (int i = 0; i < nControlPoints; i++) DisplayColor(pControlPointColors[i]);
			WriteStringToFile("\n");
		}
	}
}

void DisplayControlPointNormals(FbxMesh *pfbxMesh, int nControlPoints, int nTabIndents)
{
	FbxVector4 *pControlPointNormals = new FbxVector4[nControlPoints];

	int nNormalsPerVertex = pfbxMesh->GetElementNormalCount();
	DisplayInt("<Normals>: ", nControlPoints, nNormalsPerVertex, "\n", nTabIndents);

	if (nNormalsPerVertex > 0)
	{
		int nPolygons = pfbxMesh->GetPolygonCount();

		for (int k = 0; k < nNormalsPerVertex; k++)
		{
			DisplayInt("<Normal>: ", k, " ", nTabIndents + 1);

			FbxGeometryElementNormal *pfbxElementNormal = pfbxMesh->GetElementNormal(k);
			if (pfbxElementNormal->GetMappingMode() == FbxGeometryElement::eByControlPoint)
			{
				if (pfbxElementNormal->GetReferenceMode() == FbxGeometryElement::eDirect)
				{
					for (int i = 0; i < nControlPoints; i++) pControlPointNormals[i] = pfbxElementNormal->GetDirectArray().GetAt(i);
				}
			}
			else if (pfbxElementNormal->GetMappingMode() == FbxGeometryElement::eByPolygonVertex)
			{
				for (int i = 0, nVertexID = 0; i < nPolygons; i++)
				{
					int nPolygonSize = pfbxMesh->GetPolygonSize(i);
					for (int j = 0; j < nPolygonSize; j++, nVertexID++)
					{
						int nControlPointIndex = pfbxMesh->GetPolygonVertex(i, j);
						switch (pfbxElementNormal->GetReferenceMode())
						{
							case FbxGeometryElement::eDirect:
								pControlPointNormals[nControlPointIndex] = pfbxElementNormal->GetDirectArray().GetAt(nVertexID);
								break;
							case FbxGeometryElement::eIndexToDirect:
								pControlPointNormals[nControlPointIndex] = pfbxElementNormal->GetDirectArray().GetAt(pfbxElementNormal->GetIndexArray().GetAt(nVertexID));
								break;
							default:
								break;
						}
					}
				}
			}

			for (int i = 0; i < nControlPoints; i++) Display3DVector(pControlPointNormals[i]);
			WriteStringToFile("\n");
		}
	}
}

void DisplayControlPointTangents(FbxMesh *pfbxMesh, int nControlPoints, int nTabIndents)
{
	FbxVector4 *pControlPointTangents = new FbxVector4[nControlPoints];

	int nTangentsPerVertex = pfbxMesh->GetElementTangentCount();
	DisplayInt("<Tangents>: ", nControlPoints, nTangentsPerVertex, "\n", nTabIndents);

	if (nTangentsPerVertex > 0)
	{
		int nPolygons = pfbxMesh->GetPolygonCount();

		for (int k = 0; k < nTangentsPerVertex; k++)
		{
			DisplayInt("<Tangent>: ", k, " ", nTabIndents + 1);

			FbxGeometryElementTangent *pfbxElementTangent = pfbxMesh->GetElementTangent(k);
			if (pfbxElementTangent->GetMappingMode() == FbxGeometryElement::eByControlPoint)
			{
				if (pfbxElementTangent->GetReferenceMode() == FbxGeometryElement::eDirect)
				{
					for (int i = 0; i < nControlPoints; i++) pControlPointTangents[i] = pfbxElementTangent->GetDirectArray().GetAt(i);
				}
			}
			else if (pfbxElementTangent->GetMappingMode() == FbxGeometryElement::eByPolygonVertex)
			{
				for (int i = 0, nVertexID = 0; i < nPolygons; i++)
				{
					int nPolygonSize = pfbxMesh->GetPolygonSize(i);
					for (int j = 0; j < nPolygonSize; j++, nVertexID++)
					{
						int nControlPointIndex = pfbxMesh->GetPolygonVertex(i, j);
						switch (pfbxElementTangent->GetReferenceMode())
						{
							case FbxGeometryElement::eDirect:
								pControlPointTangents[nControlPointIndex] = pfbxElementTangent->GetDirectArray().GetAt(nVertexID);
								break;
							case FbxGeometryElement::eIndexToDirect:
								pControlPointTangents[nControlPointIndex] = pfbxElementTangent->GetDirectArray().GetAt(pfbxElementTangent->GetIndexArray().GetAt(nVertexID));
								break;
							default:
								break;
						}
					}
				}
			}

			for (int i = 0; i < nControlPoints; i++) Display3DVector(pControlPointTangents[i]);
			WriteStringToFile("\n");
		}
	}
}

void DisplayControlPointBiTangents(FbxMesh *pfbxMesh, int nControlPoints, int nTabIndents)
{
	FbxVector4 *pControlPointBiTangents = new FbxVector4[nControlPoints];

	int nBiTangentsPerVertex = pfbxMesh->GetElementBinormalCount();
	DisplayInt("<BiTangents>: ", nControlPoints, nBiTangentsPerVertex, "\n", nTabIndents);

	if (nBiTangentsPerVertex > 0)
	{
		int nPolygons = pfbxMesh->GetPolygonCount();

		for (int k = 0; k < nBiTangentsPerVertex; k++)
		{
			DisplayInt("<BiTangent>: ", k, " ", nTabIndents + 1);

			FbxGeometryElementBinormal *pfbxElementBiTangent = pfbxMesh->GetElementBinormal(k);
			if (pfbxElementBiTangent->GetMappingMode() == FbxGeometryElement::eByControlPoint)
			{
				if (pfbxElementBiTangent->GetReferenceMode() == FbxGeometryElement::eDirect)
				{
					for (int i = 0; i < nControlPoints; i++) pControlPointBiTangents[i] = pfbxElementBiTangent->GetDirectArray().GetAt(i);
				}
			}
			else if (pfbxElementBiTangent->GetMappingMode() == FbxGeometryElement::eByPolygonVertex)
			{
				for (int i = 0, nVertexID = 0; i < nPolygons; i++)
				{
					int nPolygonSize = pfbxMesh->GetPolygonSize(i);
					for (int j = 0; j < nPolygonSize; j++, nVertexID++)
					{
						int nControlPointIndex = pfbxMesh->GetPolygonVertex(i, j);
						switch (pfbxElementBiTangent->GetReferenceMode())
						{
							case FbxGeometryElement::eDirect:
								pControlPointBiTangents[nControlPointIndex] = pfbxElementBiTangent->GetDirectArray().GetAt(nVertexID);
								break;
							case FbxGeometryElement::eIndexToDirect:
								pControlPointBiTangents[nControlPointIndex] = pfbxElementBiTangent->GetDirectArray().GetAt(pfbxElementBiTangent->GetIndexArray().GetAt(nVertexID));
								break;
							default:
								break;
						}
					}
				}
			}

			for (int i = 0; i < nControlPoints; i++) Display3DVector(pControlPointBiTangents[i]);
			WriteStringToFile("\n");
		}
	}
}

void DisplayControlPoints(FbxMesh *pfbxMesh, int nControlPoints, int nTabIndents)
{
	DisplayInt("<ControlPoints>: ", nControlPoints, " ", nTabIndents);
	FbxVector4 *pfbxvControlPoints = pfbxMesh->GetControlPoints();
	for (int i = 0; i < nControlPoints; i++) Display3DVector(pfbxvControlPoints[i]);
	WriteStringToFile("\n");
}

void DisplayPolygons(FbxMesh *pfbxMesh, int nPolygons, int nTabIndents)
{
	DisplayInt("<Polygons>: ", nPolygons, "\n", nTabIndents);

	DisplayPolygonVertexIndices(pfbxMesh, nPolygons, nTabIndents + 1);

	//DisplayPolygonVertexColors(pfbxMesh, nPolygons, nTabIndents + 1);
	//DisplayPolygonVertexUVs(pfbxMesh, nPolygons, nTabIndents + 1); //UVs Per Polygon
	//DisplayPolygonVertexNormals(pfbxMesh, nPolygons, nTabIndents + 1);
	//DisplayPolygonVertexTangents(pfbxMesh, nPolygons, nTabIndents + 1);
	//DisplayPolygonVertexBinormals(pfbxMesh, nPolygons, nTabIndents + 1);

	DisplayString("</Polygons>", "", "\n", nTabIndents);
}

void DisplayMesh(FbxMesh *pfbxMesh, int nTabIndents)
{
	int nControlPoints = pfbxMesh->GetControlPointsCount();
	if (nControlPoints > 0)
	{
		DisplayControlPoints(pfbxMesh, nControlPoints, nTabIndents);

		DisplayControlPointUVs(pfbxMesh, nControlPoints, nTabIndents); //UVs Per Vertex

		DisplayControlPointNormals(pfbxMesh, nControlPoints, nTabIndents); 
		DisplayControlPointTangents(pfbxMesh, nControlPoints, nTabIndents); 
		DisplayControlPointBiTangents(pfbxMesh, nControlPoints, nTabIndents); 
	}

	int nPolygons = pfbxMesh->GetPolygonCount();
	if (nPolygons > 0) DisplayPolygons(pfbxMesh, nPolygons, nTabIndents);
}

void DisplaySkinDeformations(FbxMesh *pfbxMesh, int nTabIndents)
{
	FbxSkin *pfbxSkinDeformer = (FbxSkin *)pfbxMesh->GetDeformer(0, FbxDeformer::eSkin);
	int nClusters = pfbxSkinDeformer->GetClusterCount();

	DisplayInt("<BoneNames>: ", nClusters, " ", nTabIndents);

	for (int j = 0; j < nClusters; j++)
	{
		FbxCluster *pfbxCluster = pfbxSkinDeformer->GetCluster(j);

		FbxNode *pfbxClusterLinkNode = pfbxCluster->GetLink();
		DisplayString("", ReplaceBlank(pfbxClusterLinkNode->GetName(), '_'), " ");
	}
	WriteStringToFile("\n");

	DisplayInt("<BoneOffsets>: ", nClusters, " ", nTabIndents);

	FbxAMatrix fbxmtxGeometryOffset = GetGeometricOffsetTransform(pfbxMesh->GetNode());
	for (int j = 0; j < nClusters; j++)
	{
		FbxCluster *pfbxCluster = pfbxSkinDeformer->GetCluster(j);

		FbxAMatrix fbxmtxBindPoseMeshToRoot; //Cluster Transform
		pfbxCluster->GetTransformMatrix(fbxmtxBindPoseMeshToRoot);
		FbxAMatrix fbxmtxBindPoseBoneToRoot; //Cluster Link Transform
		pfbxCluster->GetTransformLinkMatrix(fbxmtxBindPoseBoneToRoot);

		FbxAMatrix fbxmtxVertextToLinkNode = fbxmtxBindPoseBoneToRoot.Inverse() * fbxmtxBindPoseMeshToRoot * fbxmtxGeometryOffset;

		DisplayMatrix(fbxmtxVertextToLinkNode);
	}
	WriteStringToFile("\n");

	int nControlPoints = pfbxMesh->GetControlPointsCount();

	int *pnBonesPerVertex = new int[nControlPoints];
	::memset(pnBonesPerVertex, 0, nControlPoints * sizeof(int));

	for (int j = 0; j < nClusters; j++)
	{
		FbxCluster *pfbxCluster = pfbxSkinDeformer->GetCluster(j);

		int nControlPointIndices = pfbxCluster->GetControlPointIndicesCount();
		int *pnControlPointIndices = pfbxCluster->GetControlPointIndices();
		for (int k = 0; k < nControlPointIndices; k++) pnBonesPerVertex[pnControlPointIndices[k]] += 1;
	}
	//int nMaxBonesPerVertex = 0;
	//for (int i = 0; i < nControlPoints; i++) if (pnBonesPerVertex[i] > nMaxBonesPerVertex) nMaxBonesPerVertex = pnBonesPerVertex[i];

	int **ppnBoneIDs = new int*[nControlPoints];
	float **ppnBoneWeights = new float*[nControlPoints];
	for (int i = 0; i < nControlPoints; i++)
	{
		ppnBoneIDs[i] = new int[pnBonesPerVertex[i]];
		ppnBoneWeights[i] = new float[pnBonesPerVertex[i]];
		::memset(ppnBoneIDs[i], 0, pnBonesPerVertex[i] * sizeof(int));
		::memset(ppnBoneWeights[i], 0, pnBonesPerVertex[i] * sizeof(float));
	}

	int *pnBones = new int[nControlPoints];
	::memset(pnBones, 0, nControlPoints * sizeof(int));

	for (int j = 0; j < nClusters; j++)
	{
		FbxCluster *pfbxCluster = pfbxSkinDeformer->GetCluster(j);

		int *pnControlPointIndices = pfbxCluster->GetControlPointIndices();
		double *pfControlPointWeights = pfbxCluster->GetControlPointWeights();
		int nControlPointIndices = pfbxCluster->GetControlPointIndicesCount();

		for (int k = 0; k < nControlPointIndices; k++)
		{
			int nVertex = pnControlPointIndices[k];
			ppnBoneIDs[nVertex][pnBones[nVertex]] = j;
			ppnBoneWeights[nVertex][pnBones[nVertex]] = (float)pfControlPointWeights[k];
			pnBones[nVertex] += 1;
		}
	}
					
	for (int i = 0; i < nControlPoints; i++)
	{
		for (int j = 0; j < pnBonesPerVertex[i] - 1; j++)
		{
			for (int k = j + 1; k < pnBonesPerVertex[i]; k++)
			{
				if (ppnBoneWeights[i][j] < ppnBoneWeights[i][k])
				{
					float fTemp = ppnBoneWeights[i][j];
					ppnBoneWeights[i][j] = ppnBoneWeights[i][k];
					ppnBoneWeights[i][k] = fTemp;
					int nTemp = ppnBoneIDs[i][j];
					ppnBoneIDs[i][j] = ppnBoneIDs[i][k];
					ppnBoneIDs[i][k] = nTemp;
				}
			}
		}
	}

	int (*pnSkinningIndices)[4] = new int[nControlPoints][4];
	float (*pfSkinningWeights)[4] = new float[nControlPoints][4];

	for (int i = 0; i < nControlPoints; i++)
	{
		::memset(pnSkinningIndices[i], 0, 4 * sizeof(int));
		::memset(pfSkinningWeights[i], 0, 4 * sizeof(float));

		for (int j = 0; j < pnBonesPerVertex[i]; j++)
		{
			if (j < 4)
			{
				pnSkinningIndices[i][j] = ppnBoneIDs[i][j];
				pfSkinningWeights[i][j] = ppnBoneWeights[i][j];
			}
		}
	}

	for (int i = 0; i < nControlPoints; i++)
	{
		float nSumOfBoneWeights = 0.0f;
		for (int j = 0; j < 4; j++) nSumOfBoneWeights += pfSkinningWeights[i][j];
		for (int j = 0; j < 4; j++) pfSkinningWeights[i][j] /= nSumOfBoneWeights;
	}

	DisplayInt("<BoneIndices>: ", nControlPoints, " ", nTabIndents);
	for (int i = 0; i < nControlPoints; i++)
	{
		DisplayInt(pnSkinningIndices[i][0], pnSkinningIndices[i][1], pnSkinningIndices[i][2], pnSkinningIndices[i][3]);
	}
	WriteStringToFile("\n");

	DisplayInt("<BoneWeights>: ", nControlPoints, " ", nTabIndents);
	for (int i = 0; i < nControlPoints; i++)
	{
		DisplayFloat(pfSkinningWeights[i][0], pfSkinningWeights[i][1], pfSkinningWeights[i][2], pfSkinningWeights[i][3]);
	}
	WriteStringToFile("\n");

	for (int i = 0; i < nControlPoints; i++)
	{
		if (ppnBoneIDs[i]) delete[] ppnBoneIDs[i];
		if (ppnBoneWeights[i]) delete[] ppnBoneWeights[i];
	}
	if (ppnBoneIDs) delete[] ppnBoneIDs;
	if (ppnBoneWeights) delete[] ppnBoneWeights;

	if (pnBones) delete[] pnBones;
	if (pnBonesPerVertex) delete[] pnBonesPerVertex;
	if (pnSkinningIndices) delete[] pnSkinningIndices;
	if (pfSkinningWeights) delete[] pfSkinningWeights;
}

void DisplayHierarchy(int *pnFrame, FbxNode *pfbxNode, int nTabIndents)
{
	DisplayIntString("<Frame>: ", *pnFrame, ReplaceBlank(pfbxNode->GetName(), '_'), "\n", nTabIndents);

	FbxAMatrix fbxmtxLocalTransform = pfbxNode->EvaluateLocalTransform(FBXSDK_TIME_INFINITE);

	FbxDouble3 T = pfbxNode->LclTranslation.Get();
	FbxDouble3 R = pfbxNode->LclRotation.Get();
	FbxDouble3 S = pfbxNode->LclScaling.Get();

	WriteTransform("<Transform>: ", fbxmtxLocalTransform, S, R, T, "\n", nTabIndents + 1);

	FbxNodeAttribute *pfbxNodeAttribute = pfbxNode->GetNodeAttribute();
	if (pfbxNodeAttribute)
	{
		FbxNodeAttribute::EType nAttributeType = pfbxNodeAttribute->GetAttributeType();
		if (nAttributeType == FbxNodeAttribute::eMesh)
		{
			FbxMesh *pfbxMesh = (FbxMesh *)pfbxNode->GetNodeAttribute();

			int nSkinDeformers = pfbxMesh->GetDeformerCount(FbxDeformer::eSkin);
			if (nSkinDeformers > 0)
			{
				DisplayString("<SkinDeformations>: ", "", "\n", nTabIndents + 1);
				DisplaySkinDeformations(pfbxMesh, nTabIndents + 2);
				DisplayString("</SkinDeformations>", "", "\n", nTabIndents + 1);
			}

			DisplayString("<Mesh>: ", ReplaceBlank(pfbxMesh->GetName(), '_'), "\n", nTabIndents + 1);
			DisplayMesh(pfbxMesh, nTabIndents + 2);
			DisplayString("</Mesh>", "", "\n", nTabIndents + 1);

			DisplayMaterials(pfbxMesh, nTabIndents + 1); //DisplayTexture(pfbxMesh, nTabIndents + 1);
		}
	}

	int nChilds = pfbxNode->GetChildCount();
	DisplayInt("<Children>: ", nChilds, "\n", nTabIndents + 1);

    for (int i = 0; i < nChilds; i++)
    {
		(*pnFrame)++;
        DisplayHierarchy(pnFrame, pfbxNode->GetChild(i), nTabIndents + 1);
    }

	DisplayString("</Frame>", "", "\n", nTabIndents);
}

void DisplayHierarchy(FbxScene *pfbxScene)
{
    FbxNode *pfbxRootNode = pfbxScene->GetRootNode();

	int nFrame = 0;
    for (int i = 0; i < pfbxRootNode->GetChildCount(); i++, nFrame++)
    {
        DisplayHierarchy(&nFrame, pfbxRootNode->GetChild(i), 1);
    }
}


