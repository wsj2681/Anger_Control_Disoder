#include <fbxsdk.h>
#include "DisplayCommon.h"
/*
FbxAMatrix CalculateGlobalTransform(FbxNode *pfbxNode) 
{
	FbxAMatrix fbxmtxTranslation, fbxmtxScaling, fbxmtxScalingPivot, fbxmtxScalingOffset;
	FbxAMatrix fbxmtxPreRotation, fbxmtxRotation, fbxmtxPostRotation, fbxmtxRotationOffset, fbxmtxRotationPivot;
	FbxAMatrix fbxmtxTransform;

	if (!pfbxNode)
	{
		fbxmtxTransform.SetIdentity();
		return(fbxmtxTransform);
	}

    FbxVector4 fbxf4Translation = pfbxNode->LclTranslation.Get();
    fbxmtxTranslation.SetT(fbxf4Translation);

    FbxVector4 fbxf4Rotation = pfbxNode->LclRotation.Get();
    FbxVector4 fbxf4PreRotation = pfbxNode->PreRotation.Get();
    FbxVector4 fbxf4PostRotation = pfbxNode->PostRotation.Get();
    fbxmtxRotation.SetR(fbxf4Rotation);
    fbxmtxPreRotation.SetR(fbxf4PreRotation);
    fbxmtxPostRotation.SetR(fbxf4PostRotation);

    FbxVector4 fbxf4Scaling = pfbxNode->LclScaling.Get();
    fbxmtxScaling.SetS(fbxf4Scaling);

    FbxVector4 fbxf4ScalingOffset = pfbxNode->ScalingOffset.Get();
    FbxVector4 fbxf4ScalingPivot = pfbxNode->ScalingPivot.Get();
    FbxVector4 fbxf4RotationOffset = pfbxNode->RotationOffset.Get();
    FbxVector4 fbxf4RotationPivot = pfbxNode->RotationPivot.Get();
    fbxmtxScalingOffset.SetT(fbxf4ScalingOffset);
    fbxmtxScalingPivot.SetT(fbxf4ScalingPivot);
    fbxmtxRotationOffset.SetT(fbxf4RotationOffset);
    fbxmtxRotationPivot.SetT(fbxf4RotationPivot);

    FbxAMatrix fbxmtxParentGX, fbxmtxGlobalT, fbxmtxGlobalRS;

    FbxNode *pfbxParentNode = pfbxNode->GetParent();
    if (pfbxParentNode)
	{
        fbxmtxParentGX = CalculateGlobalTransform(pfbxParentNode);
	}
	else
	{
		fbxmtxParentGX.SetIdentity();
	}

    FbxAMatrix lLRM, lParentGRM;
    FbxVector4 lParentGR = fbxmtxParentGX.GetR();
    lParentGRM.SetR(lParentGR);
    lLRM = fbxmtxPreRotation * fbxmtxRotation * fbxmtxPostRotation;

    FbxTransform::EInheritType lInheritType = pfbxNode->InheritType.Get();
    if(lInheritType == FbxTransform::eInheritRrSs)
    {
        lGlobalRS = lParentGRM * lLRM * lParentGSM * lLSM;
    }
    else if(lInheritType == FbxTransform::eInheritRSrs)
    {
        lGlobalRS = lParentGRM * lParentGSM * lLRM * lLSM;
    }
    else if(lInheritType == FbxTransform::eInheritRrs)
    {
		FbxAMatrix lParentLSM;
		FbxVector4 lParentLS = pfbxParentNode->LclScaling.Get();
		lParentLSM.SetS(lParentLS);

		FbxAMatrix lParentGSM_noLocal = lParentGSM * lParentLSM.Inverse();
        lGlobalRS = lParentGRM * lLRM * lParentGSM_noLocal * lLSM;
    }

    // Construct translation matrix
    // Calculate the local transform matrix
    fbxmtxTransform = fbxmtxTranslation * lRotationOffsetM * lRotationPivotM * lPreRotationM * lRotationM * lPostRotationM * lRotationPivotM.Inverse()\
        * lScalingOffsetM * lScalingPivotM * lScalingM * lScalingPivotM.Inverse();
    FbxVector4 lLocalTWithAllPivotAndOffsetInfo = fbxmtxTransform.GetT();
    // Calculate global translation vector according to: 
    // GlobalTranslation = ParentGlobalTransform * LocalTranslationWithPivotAndOffsetInfo
    FbxVector4 lGlobalTranslation = fbxmtxParentGX.MultT(lLocalTWithAllPivotAndOffsetInfo);
    lGlobalT.SetT(lGlobalTranslation);

    //Construct the whole global transform
    fbxmtxTransform = lGlobalT * lGlobalRS;

    return fbxmtxTransform;
}

void CompareTransformations(FbxNode *pfbxNode, FbxScene *pfbxScene)
{
    if (pfbxNode != pfbxScene->GetRootNode())
    {
        DisplayString(pfbxNode->GetName());
        FbxNode *pfbxParentNode = pfbxNode->GetParent();

        // The first way: calculate global and local transform by EvaluateGlobalTransform() and EvaluateLocalTransform().
		FbxAMatrix fbxmtxGlobal= pfbxNode->EvaluateGlobalTransform();
		FbxAMatrix fbxmtxLocal = pfbxNode->EvaluateLocalTransform();

        // The second way: calculate global and local transform from scratch by the node's properties.
        FbxAMatrix lParentTransform,lLocalTransform, fbxmtxGlobalTransform;
        FbxAMatrix fbxmtxGlobalTransform = CalculateGlobalTransform(pfbxNode);
        if(pfbxParentNode)
        {
            // Get parent global transform.
            lParentTransform = CalculateGlobalTransform(pfbxParentNode);
            // Calculate local transform according to: LocalTransform = ParentGlobalInverse * GlobalTransform.
            lLocalTransform = lParentTransform.Inverse() * fbxmtxGlobalTransform;
        }
        else
            lLocalTransform = fbxmtxGlobalTransform;

        // Compare, the results are the same. Display the global and local transformation of each joint.
        if(fbxmtxGlobal == fbxmtxGlobalTransform)
        {
            for(int i = 0; i<4; ++i)
            {
                FbxString lHeader("GlobalTransform Row_");
                FbxString lIndex(i);
                lHeader += lIndex;
                lHeader += ": ";

                Display4DVector(lHeader, fbxmtxGlobal.GetRow(i));
            }            
            FBXSDK_printf("\n");
        }
        else
        {
            FBXSDK_printf("Error: The two global transform results are not equal!\n");
            for(int i = 0; i<4; ++i)
            {
                FbxString lHeader("KFbxEvaluatorGlobalTransform Row_");
                FbxString lIndex(i);
                lHeader += lIndex;
                lHeader += ": ";

                Display4DVector(lHeader, fbxmtxGlobal.GetRow(i));
            }            
            FBXSDK_printf("\n");

            for(int i = 0; i<4; ++i)
            {
                FbxString lHeader("FromScratchGlobalTransform Row_");
                FbxString lIndex(i);
                lHeader += lIndex;
                lHeader += ": ";

                Display4DVector(lHeader, fbxmtxGlobalTransform.GetRow(i));
            }            
            FBXSDK_printf("\n");
        }

        if(fbxmtxLocal == lLocalTransform)
        {
            for(int i = 0; i<4; ++i)
            {
                FbxString lHeader("LocalTransform Row_");
                FbxString lIndex(i);
                lHeader += lIndex;
                lHeader += ": ";

                Display4DVector(lHeader, fbxmtxLocal.GetRow(i));
            }            
            FBXSDK_printf("\n");
        }
        else
        {
            FBXSDK_printf("Error: The two local transform results are not equal!\n");
            for(int i = 0; i<4; ++i)
            {
                FbxString lHeader("KFbxEvaluatorLocalTransform Row_");
                FbxString lIndex(i);
                lHeader += lIndex;
                lHeader += ": ";

                Display4DVector(lHeader, fbxmtxLocal.GetRow(i));
            }            
            FBXSDK_printf("\n");

            for(int i = 0; i<4; ++i)
            {
                FbxString lHeader("FromScratchLocalTransform Row_");
                FbxString lIndex(i);
                lHeader += lIndex;
                lHeader += ": ";

                Display4DVector(lHeader, lLocalTransform.GetRow(i));
            }            
            FBXSDK_printf("\n");
        }
    }

    int lChildCount = pfbxNode->GetChildCount();
    for( int i = 0; i<lChildCount; i++)
    {
        CompareTransformations(pfbxNode->GetChild(i), pfbxScene);
    }
}
*/
/*
Terminology:
Suffix "M" means this is a matrix, suffix "V" means it is a vector.
T is translation.
R is rotation.
S is scaling.
SH is shear.
GlobalRM(x) means the Global Rotation Matrix of node "x".
GlobalRM(P(x)) means the Global Rotation Matrix of the parent node of node "x".
All other transforms are described in the similar way.

The algorithm description:
To calculate global transform of a node x according to different InheritType, 
we need to calculate GlobalTM(x) and [GlobalRM(x) * (GlobalSHM(x) * GlobalSM(x))] separately.
GlobalM(x) = GlobalTM(x) * [GlobalRM(x) * (GlobalSHM(x) * GlobalSM(x))];

InhereitType = RrSs:
GlobalRM(x) * (GlobalSHM(x) * GlobalSM(x)) = GlobalRM(P(x)) * LocalRM(x) * [GlobalSHM(P(x)) * GlobalSM(P(x))] * LocalSM(x);

InhereitType = RSrs:
GlobalRM(x) * (GlobalSHM(x) * GlobalSM(x)) = GlobalRM(P(x)) * [GlobalSHM(P(x)) * GlobalSM(P(x))] * LocalRM(x) * LocalSM(x);

InhereitType = Rrs:
GlobalRM(x) * (GlobalSHM(x) * GlobalSM(x)) = GlobalRM(P(x)) * LocalRM(x) * LocalSM(x);

LocalM(x)= TM(x) * RoffsetM(x)  * RpivotM(x) * RpreM(x) * RM(x) * RpostM(x) * RpivotM(x)^-1 * SoffsetM(x) *SpivotM(x) * SM(x) * SpivotM(x)^-1
LocalTWithAllPivotAndOffsetInformationV(x) = Local(x).GetT();
GlobalTV(x) = GlobalM(P(x)) * LocalTWithAllPivotAndOffsetInformationV(x);

Notice: FBX SDK does not support shear yet, so all local transform won't have shear.
However, global transform might bring in shear by combine the global transform of node in higher hierarchy.
For example, if you scale the parent by a non-uniform scale and then rotate the child node, then a shear will
be generated on the child node's global transform.
In this case, we always compensates shear and store it in the scale matrix too according to following formula:
Shear*Scaling = RotationMatrix.Inverse * TranslationMatrix.Inverse * WholeTranformMatrix
*/
