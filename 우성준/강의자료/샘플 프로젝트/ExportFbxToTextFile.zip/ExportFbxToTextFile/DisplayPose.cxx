/****************************************************************************************

   Copyright (C) 2015 Autodesk, Inc.
   All rights reserved.

   Use of this software is subject to the terms of the Autodesk license agreement
   provided at the time of installation or download, or which otherwise accompanies
   this software in either electronic or hard copy form.

****************************************************************************************/

#include "DisplayPose.h"

void DisplayPose(FbxScene *pfbxScene)
{
    int nPoses = pfbxScene->GetPoseCount();
	DisplayInt("<Poses>: ", nPoses, "\n", 0);

    for (int i = 0; i < nPoses; i++)
    {
		DisplayInt("<Pose>: ", i, " ", 1);

		FbxPose *pfbxPose = pfbxScene->GetPose(i);
		FbxString fbxName = pfbxPose->GetName();
        DisplayIntString("", pfbxPose->IsBindPose() ? 1 : 0, ReplaceBlank(pfbxPose->GetName(), '_'), " ");

		int nPoseItems = pfbxPose->GetCount();
        DisplayInt("", pfbxPose->IsBindPose() ? 1 : 0, nPoseItems, "\n");

        for (int j = 0; j < nPoseItems; j++)
        {
			DisplayIntString("<PoseItem>: ", j, ReplaceBlank(pfbxPose->GetNodeName(j).GetCurrentName(), '_'), " ", 2);

            if (pfbxPose->IsBindPose()) DisplayInt(1);
			else DisplayInt(pfbxPose->IsLocalMatrix(j) ? 0 : 1);
//			DisplayString(" ");

            FbxMatrix fbxPoseMatrix = pfbxPose->GetMatrix(j);
			DisplayMatrix(fbxPoseMatrix);

			DisplayString("\n");
		}
    }
	DisplayString("", "</Poses>", "\n", 0);

    int nCharacterPoses = pfbxScene->GetCharacterPoseCount();
	DisplayInt("<CharacterPoses>: ", nCharacterPoses, "\n", 0);

    for (int i = 0; i < nCharacterPoses; i++)
    {
		DisplayInt("<CharacterPose>: ", i, " ", 1);

		FbxCharacterPose *pfbxPose = pfbxScene->GetCharacterPose(i);
        FbxCharacter *pfbxCharacter = pfbxPose->GetCharacter();

        if (!pfbxCharacter) break;

		DisplayString("", ReplaceBlank(pfbxCharacter->GetName(), '_'), " ");

        FbxCharacterLink fbxCharacterLink;
        FbxCharacter::ENodeId nNodeId = FbxCharacter::eHips;

        while (pfbxCharacter->GetCharacterLink(nNodeId, &fbxCharacterLink))
        {
            FbxAMatrix& fbxGlobalPosition = fbxCharacterLink.mNode->EvaluateGlobalTransform(FBXSDK_TIME_ZERO);
			DisplayMatrix(fbxGlobalPosition);

			nNodeId = FbxCharacter::ENodeId(int(nNodeId) + 1);
        }
		DisplayString("\n");
	}
	DisplayString("", "</CharacterPoses>", "\n", 0);
}


